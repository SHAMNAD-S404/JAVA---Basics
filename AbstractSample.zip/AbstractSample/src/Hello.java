
public abstract class Hello {
	abstract void onText(String name);
}
